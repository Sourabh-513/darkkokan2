# Material player

A Pen created on CodePen.io. Original URL: [https://codepen.io/Hylix/pen/wKbpdX](https://codepen.io/Hylix/pen/wKbpdX).

inspired by https://dribbble.com/shots/2365362-A-or-B-Bottom-music-player-dashboard